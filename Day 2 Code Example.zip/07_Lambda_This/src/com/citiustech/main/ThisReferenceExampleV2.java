package com.citiustech.main;

public class ThisReferenceExampleV2 {

	public void doProcess(int i, Process p) {
		p.process(i);
	}

	public void execute() {
		doProcess(10, i -> {
			System.out.println("Value of i :: " + i);
			System.out.println(this);
		});
	}

	public static void main(String[] args) {
		ThisReferenceExampleV2 thisReferenceExample = new ThisReferenceExampleV2();
		thisReferenceExample.execute();

//		thisReferenceExample.doProcess(10, new Process() {
//			@Override
//			public void process(int i) {
//				System.out.println("Value of i :: " + i);
//				System.out.println(this);
//			}
//
//			@Override
//			public String toString() {
//				return "toString of anonymous inner class";
//			}
//		});

//		thisReferenceExample.doProcess(10, i -> {
//			System.out.println("Value of i :: " + i);
//			System.out.println(this);
//		});

	}

	@Override
	public String toString() {
		return "toString of ThisReferenceExample";
	}
}
