package com.citiustech.main;

public class ThisReferenceExample {

	public void doProcess(int i, Process p) {
		p.process(i);
	}

	public static void main(String[] args) {
		ThisReferenceExample thisReferenceExample = new ThisReferenceExample();

		thisReferenceExample.doProcess(10, new Process() {
			@Override
			public void process(int i) {
				System.out.println("Value of i :: " + i);
				System.out.println(this);
			}

			@Override
			public String toString() {
				return "toString of anonymous inner class";
			}
		});
	}

	@Override
	public String toString() {
		return "toString of ThisReferenceExample";
	}
}

interface Process {
	void process(int i);
}
