package com.citiustech.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.citiustech.pojo.Person;

public class PersonMain_Java_8 {

	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharelar", 33),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		// step 1 :: Sort the list by last name
		Collections.sort(people, (p1, p2) -> p1.getLastName().compareTo(p2.getLastName()));

		// step 2 :: Create a method that prints all the people in the list
		// printAll(people);
		printConditionally(people, p -> true);

		System.out.println("-----------------------------------------");

		// step 3 :: Create a method that prints all the people that have last name
		// begining with G
		// printConditionally(people, p -> p.getLastName().startsWith("G"));

		Condition personLastNameCondition = p -> p.getLastName().startsWith("G");
		printConditionally(people, personLastNameCondition);

		printConditionally(people, p -> p.getLastName().startsWith("G"));

	}

	public static void printConditionally(List<Person> people, Condition condition) {
		for (Person person : people) {
			if (condition.test(person))
				System.out.println(person);
		}
	}

//	private static void printAll(List<Person> people) {
//		for (Person person : people) {
//			System.out.println(person);
//		}
//	}
}
