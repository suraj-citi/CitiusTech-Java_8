package com.citiustech.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.citiustech.pojo.Person;

public class PersonMain_Java_7 {
	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Vivek", "Gohil", 31), new Person("Trupti", "Acharelar", 33),
				new Person("Gurubux", "Gill", 30), new Person("Samarth", "Patil", 10));

		// step 1 :: Sort the list by last name
		Collections.sort(people, new Comparator<Person>() {
			public int compare(Person p1, Person p2) {
				return p1.getLastName().compareTo(p2.getLastName());
			};
		});

		// step 2 :: Create a method that prints all the people in the list
		printAll(people);
		System.out.println("------------------------------------------------------");
		// step 3 :: Create a method that prints all the people that have last name
		// begining with G
		// printLastNameBeginningWithG(people);

		printConditionally(people, new Condition() {
			@Override
			public boolean test(Person person) {
				if (person.getLastName().startsWith("G"))
					return true;
				return false;
			}
		});
	}

//	private static void printLastNameBeginningWithG(List<Person> people) {
//		for (Person person : people) {
//			if (person.getLastName().startsWith("G"))
//				System.out.println(person);
//		}
//	}
	public static void printConditionally(List<Person> people, Condition condition) {
		for (Person person : people) {
			if (condition.test(person))
				System.out.println(person);
		}
	}
	private static void printAll(List<Person> people) {
		for (Person person : people) {
			System.out.println(person);
		}

	}
}
interface Condition {
	boolean test(Person person);
}
