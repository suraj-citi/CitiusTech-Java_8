package com.citiustech.dao;

import java.util.HashSet;

import com.citiustech.pojo.Employee;

public class EmployeeDAO {

	private HashSet<Employee> employeeSet = new HashSet<Employee>();

	public void addEmployee(Employee employee) {
		employeeSet.add(employee);
	}

	public void updateEmployee(Employee newEmployee) {
		// update name / salary
	}

	public void deleteEmployee(int employeeId) {

	}

	public Employee getEmployeeByEmployeeId(int employeeId) {
		return null;
	}

	public HashSet<Employee> getAllEmployees() {
		return employeeSet;
	}
}
