package com.citiustech.main;

import com.citiustech.dao.EmployeeDAO;
import com.citiustech.pojo.Employee;

public class HashSetEmployeeMain {

	public static void main(String[] args) {

		EmployeeDAO dao = new EmployeeDAO();

		// Add three employees
		Employee employee1 = new Employee(101, "Vivek", 1000);
		System.out.println("HashCode of employee1 :: " + employee1.hashCode());
		
		Employee employee2 = new Employee(103, "Suraj", 2000);
		System.out.println("HashCode of employee2 :: " + employee2.hashCode());
		
		Employee employee3 = new Employee(101, "Vivek", 1000);
		System.out.println("HashCode of employee3 :: " + employee3.hashCode());
		
		System.out.println("=================================================");

		dao.addEmployee(employee1);
		System.out.println("---------------------");
		dao.addEmployee(employee2);
		System.out.println("---------------------");
		dao.addEmployee(employee3);

		// update salary of first employee

		// remove second employee

		// print last employee

		// print all employees
		for (Employee employee : dao.getAllEmployees()) {
			System.out.println(employee);
		}

	}

}
