package com.citiustech.main;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.citiustech.pojo.Employee;

public class MapApplication {
	public static void main(String[] args) {
		Map mapA = new HashMap();
		Map mapB = new TreeMap();

		mapA = new TreeMap();
		mapB = new HashMap();

		// Map<int, double> myMap = new HashMap<>();
		Map<Integer, Employee> employeeMap = new TreeMap<Integer, Employee>();

		Employee employee = new Employee(0,"Vivek", 1000);
		Employee employee2 = new Employee(0,"Trupti", 2000);
		Employee employee3 = new Employee(0,"Prajakta", 1000);

		employeeMap.put(101, employee);
		employeeMap.put(102, employee2);
		employeeMap.put(103, employee3);

		System.out.println(employeeMap);

		System.out.println("========================================");

		Map<Integer, Employee> newEmployeeMap = new HashMap<Integer, Employee>();
		newEmployeeMap.putAll(employeeMap);

		System.out.println(newEmployeeMap);

		System.out.println("========================================");

		Employee emp = employeeMap.get(102);
		System.out.println(emp);

		System.out.println("========================================");
		System.out.println(employeeMap.get(102));

		System.out.println("========================================");
		System.out.println(employeeMap.get(10));

		System.out.println("========================================");

		System.out.println(employeeMap.getOrDefault(10, new Employee()));

		System.out.println("========================================");

		if (employeeMap.containsKey(10))
			System.out.println(employeeMap.get(10));
		else
			System.out.println("No key found!!");

		System.out.println("========================================");

		Iterator<Integer> iterator = employeeMap.keySet().iterator();

		while (iterator.hasNext()) {
			int employeeId = iterator.next();
			System.out.print(employeeId + "  ");
		}
		System.out.println();
		System.out.println("========================================");

		Iterator<Integer> iterator2 = employeeMap.keySet().iterator();

		while (iterator2.hasNext()) {
			int employeeId = iterator2.next();
			Employee empTemp = employeeMap.get(employeeId);
			System.out.print("key :: " + employeeId + "  ");
			System.out.println("Value :: " + empTemp.getName() + " and  " + empTemp.getSalary());
		}

		System.out.println("========================================");

		for (Integer employeeId : employeeMap.keySet()) {
			Employee empTemp = employeeMap.get(employeeId);
			System.out.print("key :: " + employeeId + "  ");
			System.out.println("Value :: " + empTemp.getName() + " and  " + empTemp.getSalary());
		}

		System.out.println("========================================");

		Iterator<Employee> employeeIterator = employeeMap.values().iterator();

		while (employeeIterator.hasNext()) {
			Employee empTemp = (Employee) employeeIterator.next();
			System.out.println("Value :: " + empTemp.getName() + " and  " + empTemp.getSalary());
		}

		System.out.println("========================================");

		for (Employee empTemp : employeeMap.values()) {
			System.out.println("Value :: " + empTemp.getName() + " and  " + empTemp.getSalary());
		}

		System.out.println("========================================");

		Set<Map.Entry<Integer, Employee>> entries = employeeMap.entrySet();
		Iterator<Map.Entry<Integer, Employee>> entriesIterator = entries.iterator();

		while (entriesIterator.hasNext()) {
			Map.Entry<Integer, Employee> entry = entriesIterator.next();
			System.out.println("Key :: " + entry.getKey());
			System.out.println("Value :: " + entry.getValue());
			System.out.println("----------------------------------");
		}

		System.out.println("========================================");

		for (Map.Entry<Integer, Employee> entry : entries) {
			System.out.println("Key :: " + entry.getKey());
			System.out.println("Value :: " + entry.getValue());
			System.out.println("----------------------------------");
		}
		
		System.out.println("========================================");
		employeeMap.remove(101);
		System.out.println(employeeMap);
		
		System.out.println("========================================");
		employeeMap.clear();
		System.out.println(employeeMap);
		
	}
}
