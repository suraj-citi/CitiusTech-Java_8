package com.citiustech.main;

@FunctionalInterface
public interface Greeting {
	public void perfom();
	//public void myMethod();
}
