package com.citiustech.main;

public class HelloWorldGreeting implements Greeting {
	@Override
	public void perfom() {
		System.out.println("Good Morning");
	}
}
