package com.citiustech.main;

public class TypeInferenceExample {
	public static void main(String[] args) {
		// StringLengthLambda stringLengthLambda = (s) -> s.length();
		// System.out.println("String length :: " + stringLengthLambda.getLength("Hello
		// World !!"));

		StringLengthLambda stringLengthLambda;

		// stringLengthLambda = (String s) -> s.length();
		// stringLengthLambda = (s) -> s.length();
		stringLengthLambda = s -> s.length();

		// System.out.println("String length :: " + stringLengthLambda.getLength("Hello
		// World!"));
		printLambda(s -> s.length());

		ArithmethicOperationInterface add = (num1, num2) -> num1 + num2;
		System.out.println(add.calculateResult(10, 20));

		ArithmethicOperationInterface sub = (num1, num2) -> num1 - num2;
		System.out.println(sub.calculateResult(10, 20));

		ArithmethicOperationInterface multi = (num1, num2) -> num1 * num2;
		System.out.println(multi.calculateResult(10, 20));

		ArithmethicOperationInterface div = (num1, num2) -> num1 / num2;
		System.out.println(div.calculateResult(10, 2));

		System.out.println("------------------------------------------------");

		calculateLambda((num1, num2) -> num1 + num2);
		calculateLambda((num1, num2) -> num1 - num2);
		calculateLambda((num1, num2) -> num1 * num2);
		calculateLambda((num1, num2) -> num1 / num2);

		System.out.println("------------------------------------------------");

		calculateLambda((num1, num2) -> num1 + num2, 10, 2);
		calculateLambda((num1, num2) -> num1 - num2, 10, 5);
		calculateLambda((num1, num2) -> num1 * num2, 10, 3);
		calculateLambda((num1, num2) -> num1 / num2, 10, 2);

	}

	public static void printLambda(StringLengthLambda stringLengthLambda) {
		System.out.println(stringLengthLambda.getLength("Hello World"));
	}

	public static void calculateLambda(ArithmethicOperationInterface arithmeticOperation) {
		System.out.println("Result is :: " + arithmeticOperation.calculateResult(10, 2));
	}

	public static void calculateLambda(ArithmethicOperationInterface arithmeticOperation, double num1, double num2) {
		System.out.println("Result is :: " + arithmeticOperation.calculateResult(num1, num2));
	}

	interface ArithmethicOperationInterface {
		double calculateResult(double num1, double num2);
	}
}

//create functional interface as ArithmeticOperationInterface 
//with calculateResult(double num1 , double num2) method.

//Pass the lambda expression to do + , - , * , / operations. 
