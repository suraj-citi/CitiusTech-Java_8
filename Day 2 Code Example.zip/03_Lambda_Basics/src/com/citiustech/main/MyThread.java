package com.citiustech.main;

public class MyThread extends Thread {
	@Override
	public void run() {
		System.out.println("Printed inside run of thread");
	}
}
