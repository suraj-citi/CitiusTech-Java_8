package com.citiustech.main;

public class RunnableExample {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		myThread.start();

		Thread runnableThread = new Thread(new Runnable() {

			@Override
			public void run() {
				System.out.println("We are in runnable Thread");
			}
		});
		runnableThread.start();

		Thread myLambdaThread = new Thread(() -> System.out.println("We are in myLambdaThread !"));
		myLambdaThread.start();
	}

}
