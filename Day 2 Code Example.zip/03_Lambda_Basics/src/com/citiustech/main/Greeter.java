package com.citiustech.main;

public class Greeter {
//	public void greet() {
//		System.out.println("Hello World");
//	}

	public void greet(Greeting greeting) {
		greeting.perfom();
	}

	public static void main(String[] args) {
		Greeter greeter = new Greeter();
		// greeter.greet();

		// HelloWorldGreeting helloWorldGreeting = new HelloWorldGreeting();
		// greeter.greet(helloWorldGreeting);

		// GoodMorningGreeting goodMorningGreeting = new GoodMorningGreeting();
		// greeter.greet(goodMorningGreeting);

		// first apprch
		Greeting objectGreeting = new HelloWorldGreeting();
		objectGreeting.perfom();

		// inner class
		Greeting innerClassGreeting = new Greeting() {
			@Override
			public void perfom() {
				System.out.println("Good Afternoon");
			}
		};
		innerClassGreeting.perfom();

		// lambda Expression
		Greeting lambdaGreeting = () -> System.out.println("Good Evening");
		lambdaGreeting.perfom();

//		int x;
//		String message;
//		Greeting myFirstLambdaFunction;
//		Greeting mySecondLambdaFunction;
//
//		myFirstLambdaFunction = () -> System.out.println("Hello World");
//		greeter.greet(myFirstLambdaFunction);
//
//		mySecondLambdaFunction = () -> System.out.println("Good Morning");
//		greeter.greet(mySecondLambdaFunction);

	}

}
