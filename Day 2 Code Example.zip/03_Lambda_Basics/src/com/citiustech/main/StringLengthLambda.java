package com.citiustech.main;

public interface StringLengthLambda {
	int getLength(String s);
}
