package com.citiustech.main;

import java.util.function.BiConsumer;

public class ExceptionHandlingMainV3 {

	public static void main(String[] args) {
		int[] someNumbers = { 2, 4, 6, 8, 10 };
		// int key = 2;
		int key = 0;

		// lets introduce an exception by setting key = 0
		process(someNumbers, key, (i, k) -> System.out.println(i + k));
		System.out.println("----------------------------------------");
		process(someNumbers, key, (i, k) -> System.out.println(i - k));
		System.out.println("----------------------------------------");
		process(someNumbers, key, (i, k) -> {
			try {
				System.out.println(i / k);
			} catch (ArithmeticException e) {
				System.out.println(e.getMessage());
			}
		});
		System.out.println("----------------------------------------");
		process(someNumbers, key, (i, k) -> System.out.println(i * k));

	}

//	private static void process(int[] someNumbers, int key, BiConsumer<Integer, Integer> biConsumer) {
//		for (int i : someNumbers) {
//			System.out.println("Value of i = " + i);
//			System.out.println("Value of key = " + key);
//			System.out.println("_________________");
//			try {
//				biConsumer.accept(i, key);
//			} catch (ArithmeticException e) {
//				System.out.println(e.getMessage());
//			}
//			System.out.println("_________________");
//		}
//	}

	private static void process(int[] someNumbers, int key, BiConsumer<Integer, Integer> biConsumer) {
		for (int i : someNumbers) {
			System.out.println("Value of i = " + i);
			System.out.println("Value of key = " + key);
			System.out.println("_________________");
			biConsumer.accept(i, key);
			System.out.println("_________________");
		}
	}
}
