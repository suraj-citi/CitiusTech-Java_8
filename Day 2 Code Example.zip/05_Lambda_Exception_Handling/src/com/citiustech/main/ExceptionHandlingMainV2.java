package com.citiustech.main;

import java.util.function.BiConsumer;

public class ExceptionHandlingMainV2 {

	public static void main(String[] args) {
		int[] someNumbers = { 2, 4, 6, 8, 10 };
		int key = 2;

		// lets say i want to add a number(key) to all the elements of array.
		// i want to convert the arithmetic operation into lambda expression
		// so that i can do the any arithmetic operation which i pass
		// process(someNumbers, key);
		process(someNumbers, key, (i, k) -> System.out.println(i + k));
		System.out.println("----------------------------------------");
		process(someNumbers, key, (i, k) -> System.out.println(i - k));
		System.out.println("----------------------------------------");
		process(someNumbers, key, (i, k) -> System.out.println(i / k));
		System.out.println("----------------------------------------");
		process(someNumbers, key, (i, k) -> System.out.println(i * k));

	}

	private static void process(int[] someNumbers, int key, BiConsumer<Integer, Integer> biConsumer) {
		for (int i : someNumbers) {
			System.out.println("Value of i = " + i);
			System.out.println("Value of key = " + key);
			System.out.println("_________________");
			biConsumer.accept(i, key);
			System.out.println("_________________");
		}
	}
}
