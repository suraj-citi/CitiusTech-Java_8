package com.citiustech.main;

import java.util.function.BiConsumer;

public class ExceptionHandlingMainV5 {

	public static void main(String[] args) {
		int[] someNumbers = { 2, 4, 6, 8, 10 };
		// int key = 2;
		int key = 0;

		process(someNumbers, key, wrapperLambda((i, k) -> System.out.println(i + k)));
	}

	private static void process(int[] someNumbers, int key, BiConsumer<Integer, Integer> biConsumer) {
		System.out.println("In Process");
		for (int i : someNumbers) {
			System.out.println("Value of i = " + i);
			System.out.println("Value of key = " + key);
			System.out.println("_________________");
			biConsumer.accept(i, key);
			System.out.println("_________________");
		}
	}

	public static BiConsumer<Integer, Integer> wrapperLambda(BiConsumer<Integer, Integer> biConsumer) {
		System.out.println("wrapperLambda");
		return (i, k) -> {
			System.out.println("In wrapperLambda , value of i :: " + i + "and value of k :: " + k);
			System.out.println(i - k);
		};
	}
}
