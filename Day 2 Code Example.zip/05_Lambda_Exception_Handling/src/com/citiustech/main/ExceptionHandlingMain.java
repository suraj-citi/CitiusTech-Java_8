package com.citiustech.main;

public class ExceptionHandlingMain {

	public static void main(String[] args) {
		int[] someNumbers = { 2, 4, 6, 8, 10 };
		int key = 2;

		// lets say i want to add a number(key) to all the elements of array.
		process(someNumbers, key);
	}

	private static void process(int[] someNumbers, int key) {
		for (int i : someNumbers) {
			System.out.println(i + key);
		}
	}
}
