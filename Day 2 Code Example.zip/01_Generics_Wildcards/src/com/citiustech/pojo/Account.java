package com.citiustech.pojo;

public class Account {
	public void accountTransactions() {
		System.out.println("Doing Account Transactions");
	}
}
