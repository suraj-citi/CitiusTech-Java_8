package com.citiustech.pojo;

public class Savings extends Account {
	@Override
	public void accountTransactions() {
		System.out.println("Savings Account Transactions");
	}
}
