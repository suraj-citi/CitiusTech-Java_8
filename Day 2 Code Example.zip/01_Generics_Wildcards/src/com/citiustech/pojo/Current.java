package com.citiustech.pojo;

public class Current extends Account {
	@Override
	public void accountTransactions() {
		System.out.println("Current Account Transactions");
	}
}
