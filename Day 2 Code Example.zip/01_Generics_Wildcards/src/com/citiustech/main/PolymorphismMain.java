package com.citiustech.main;

import com.citiustech.pojo.Account;
import com.citiustech.pojo.Current;
import com.citiustech.pojo.Savings;

public class PolymorphismMain {
	public static void main(String[] args) {
		
		Account account;
		account = new Savings();	
		account = new Current();
		
		print(account);
		
	}
	
	public static void print(Account account) {
		account.accountTransactions();
	}
}
