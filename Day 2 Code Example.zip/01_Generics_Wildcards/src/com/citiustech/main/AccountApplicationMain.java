package com.citiustech.main;

import java.util.ArrayList;
import java.util.List;

import com.citiustech.pojo.Account;
import com.citiustech.pojo.Current;
import com.citiustech.pojo.Savings;

public class AccountApplicationMain {
	public static void main(String[] args) {
		// level 0
		System.out.println("Start");

		Account account = new Account();
		Current current = new Current();
		Savings savings = new Savings();

		account = current;
		account = savings;

		ArrayList<Account> listAccount = new ArrayList<Account>();
		listAccount.add(account);
		listAccount.add(savings);
		listAccount.add(current);

		ArrayList<Current> listCurrent = new ArrayList<>();
		ArrayList<Savings> listSavings = new ArrayList<>();
		listSavings.add(savings);
		// listSavings.add(account);

		// listAccount = listSavings;

		ArrayList<?> listAccount2 = new ArrayList<Account>();
		listAccount2 = listSavings;

		List<? extends Account> listAccount3 = new ArrayList<Account>();
		listAccount3 = listAccount;
		listAccount3 = listSavings;
		listAccount3 = listCurrent;

		printAccountsTransactions(listAccount);

		List<? super Account> listAccount4 = new ArrayList<Account>();
		listAccount4 = listAccount;
		// listAccount4 = listSavings;

		printAccountsTransactions(listAccount4);
		System.out.println("End");
	}

//	public static void printAccountsTransactions(List<? extends Account> accounts) {
//		for (Account account : accounts) {
//			account.accountTransactions();
//		}
//	}

	public static void printAccountsTransactions(List<? super Account> accounts) {
		for (Account account : (ArrayList<Account>) accounts) {
			account.accountTransactions();
		}
	}
}
