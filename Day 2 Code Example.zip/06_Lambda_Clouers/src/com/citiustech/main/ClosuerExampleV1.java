package com.citiustech.main;

public class ClosuerExampleV1 {
	public static void main(String[] args) {
		int a = 10;
		int b = 20;

//		doProcess(a, new process() {
//			@Override
//			public void process(int i) {
//				System.out.println("i = " + (i + 10));
//				System.out.println("b = " + b);
//				//b = 30;
//			}
//		});

		doProcess(a, i -> {
			System.out.println("i = " + i);
			System.out.println("a = " + a);
			System.out.println("b = " + b);
			// a = 20;
		});
	}

	public static void doProcess(int i, process p) {
		p.process(i);
	}
}

interface process {
	void process(int i);
}